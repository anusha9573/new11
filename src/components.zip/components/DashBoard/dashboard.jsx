import React from 'react';
import './Dashboard.css'; // Make sure to import your CSS file

function Dashboard() {
  return (
    <div>
      <header>
        <h2 href="#">Voyage Verve</h2>
        <nav className="home-link">
        <li><a href="#" className="home-link" >About</a></li>
          <li><a href="#" className="home-link">Contact us</a></li>
          <li><a href="#" className="home-link">Search</a></li>
          <li><a href="#" className="home-link">Destination Guides</a></li>
          <li><a href="/login" className="home-link">Sign In</a></li>
          <li><a href="#" className="home-link">Profile</a></li>
        </nav>
      </header>

      <section className="hero" style={{backgroundImage: 'url(https://wallpapercave.com/wp/wp4069436.jpg)'}}>
        <div className="hero-content-area">
          <h1>Voyage Verve</h1>
          <h3>Journey beyond the guidebooks and discover the world through fresh eyes with our travel blog. Your adventure starts here, where every destination is a story waiting to be told</h3>
          <a href="/blog" className="btn">Create Ur Blog</a>
        </div>
      </section>

    

      <section className="destinations">
        <h3 className="title">Rest information will go here:</h3>
        <p>blah blash blahs blahs blahss</p>
        <hr />
      </section>

      <section className="contact">
        <h3 className="title">Join our newsletter</h3>
        <p>Information will go here (if any)</p>
        <hr />

        <form>
          <input type="email" placeholder="Email" />
          <a href="#" className="btn">Subscribe now</a>
        </form>
      </section>

      <footer>
        <ul>
          <li><a href="#"><i className="fa fa-twitter-square"></i></a></li>
          <li><a href="#"><i className="fa fa-facebook-square"></i></a></li>
          <li><a href="#"><i className="fa fa-snapchat-square"></i></a></li>
          <li><a href="#"><i className="fa fa-pinterest-square"></i></a></li>
          <li><a href="#"><i className="fa fa-github-square"></i></a></li>
        </ul>
        <p>Made by Pardeep Singh</p>
        <p>No attribution required. You can remove this footer.</p>
      </footer>
    </div>
  );
}

export default Dashboard;
